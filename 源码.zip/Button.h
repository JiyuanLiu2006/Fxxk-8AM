#pragma once
#include <windows.h>
#include <gdiplus.h>

inline void AddRoundRect(Gdiplus::GraphicsPath &path, const Gdiplus::Rect &r, float radius)
{
    float d = radius * 2.0f;
    path.StartFigure();
    path.AddArc((Gdiplus::REAL)r.X, (Gdiplus::REAL)r.Y, (Gdiplus::REAL)d, (Gdiplus::REAL)d, 180, 90);
    path.AddArc((Gdiplus::REAL)(r.X + r.Width - d), (Gdiplus::REAL)r.Y, (Gdiplus::REAL)d, (Gdiplus::REAL)d, 270, 90);
    path.AddArc((Gdiplus::REAL)(r.X + r.Width - d), (Gdiplus::REAL)(r.Y + r.Height - d), (Gdiplus::REAL)d, (Gdiplus::REAL)d, 0, 90);
    path.AddArc((Gdiplus::REAL)r.X, (Gdiplus::REAL)(r.Y + r.Height - d), (Gdiplus::REAL)d, (Gdiplus::REAL)d, 90, 90);
    path.CloseFigure();
}

inline void DrawButton(Gdiplus::Graphics &g, const Gdiplus::Rect &btnRect, const WCHAR *text, float fontSize, const Gdiplus::Color &btnColor, const Gdiplus::Color &textColor, bool hover = false, bool pressed = false) {
    g.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);

    //��Ӱ
    const int shadowSteps = 12;
    float baseCornerR = (float)btnRect.Height * 0.28f;
    for (int i = shadowSteps; i >= 1; --i) {
        int alpha = (int)(140.0f * (float)i / (float)shadowSteps);
        if (alpha > 255) alpha = 255;
        Gdiplus::Color shadowColor((BYTE)alpha, 200, 200, 200);
        Gdiplus::SolidBrush shadowBrush(shadowColor);
        int expand = (shadowSteps - i) * 3;
        Gdiplus::Rect r3(btnRect);
        r3.X -= expand / 2;
        r3.Y -= expand / 2;
        r3.Width += expand;
        r3.Height += expand;
        Gdiplus::GraphicsPath sp;
        float cornerR = baseCornerR;
        if (btnRect.Height > 0) {
            float scale = (float)r3.Height / (float)btnRect.Height;
            cornerR = baseCornerR * scale;
        }
        AddRoundRect(sp, r3, cornerR);
        g.FillPath(&shadowBrush, &sp);
    }

    //��ť������
    Gdiplus::GraphicsPath btnPath;
    float cornerR = (float)btnRect.Height * 0.28f;
    AddRoundRect(btnPath, btnRect, cornerR);
    Gdiplus::Color creamCol = Gdiplus::Color(255, 250, 240);
    if (hover) {
        creamCol = Gdiplus::Color(255, 252, 246);
    }
    if (pressed) {
        creamCol = Gdiplus::Color(255, 245, 235);
    }
    Gdiplus::SolidBrush creamBrush(creamCol);
    g.FillPath(&creamBrush, &btnPath);
    //�ڲ�����
    Gdiplus::RectF topRectF((Gdiplus::REAL)btnRect.X + 1, (Gdiplus::REAL)btnRect.Y + 1, (Gdiplus::REAL)btnRect.Width - 2, (Gdiplus::REAL)(btnRect.Height * 0.45f));
    Gdiplus::GraphicsPath topPath;
    Gdiplus::Rect topRect((int)topRectF.X, (int)topRectF.Y, (int)topRectF.Width, (int)topRectF.Height);
    AddRoundRect(topPath, topRect, cornerR * 0.8f);
    Gdiplus::PathGradientBrush pgbTop(&topPath);
    Gdiplus::Color centerTop(200, 255, 255, 255);
    pgbTop.SetCenterColor(centerTop);
    Gdiplus::Color surroundTop[1] = { Gdiplus::Color(0,255,255,255) };
    INT sc = 1;
    pgbTop.SetSurroundColors(surroundTop, &sc);
    pgbTop.SetFocusScales(0.7f, 0.7f);
    g.FillPath(&pgbTop, &topPath);

    //�߿�
    Gdiplus::Pen borderPen(Gdiplus::Color(64, 200, 200, 200), 1.0f);
    borderPen.SetLineJoin(Gdiplus::LineJoinRound);
    g.DrawPath(&borderPen, &btnPath);

    //�ı�
    Gdiplus::Font btnFont(L"Microsoft YaHei", fontSize, Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
    Gdiplus::SolidBrush btnTextBrush(Gdiplus::Color(255, 64, 64, 64));
    Gdiplus::StringFormat btnFmt;
    btnFmt.SetAlignment(Gdiplus::StringAlignmentCenter);
    btnFmt.SetLineAlignment(Gdiplus::StringAlignmentCenter);
    btnFmt.SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap);
    btnFmt.SetTrimming(Gdiplus::StringTrimmingEllipsisCharacter);
    Gdiplus::SolidBrush textShadow(Gdiplus::Color(100, 0, 0, 0));
    Gdiplus::RectF btnRectF(static_cast<Gdiplus::REAL>(btnRect.X), static_cast<Gdiplus::REAL>(btnRect.Y), static_cast<Gdiplus::REAL>(btnRect.Width), static_cast<Gdiplus::REAL>(btnRect.Height));
    Gdiplus::PointF shadowOffset(0.0f, pressed ? 2.0f : 1.0f);
    Gdiplus::RectF shadowRectF(btnRectF.X + shadowOffset.X, btnRectF.Y + shadowOffset.Y, btnRectF.Width, btnRectF.Height);
    g.SetTextRenderingHint(Gdiplus::TextRenderingHintClearTypeGridFit);
    //������£�����������΢����
    Gdiplus::Matrix old;
    g.GetTransform(&old);
    if (pressed) g.TranslateTransform(0.0f, 1.0f);
    g.DrawString(text, -1, &btnFont, shadowRectF, &btnFmt, &textShadow);
    g.DrawString(text, -1, &btnFont, btnRectF, &btnFmt, &btnTextBrush);
    g.SetTransform(&old);
}
