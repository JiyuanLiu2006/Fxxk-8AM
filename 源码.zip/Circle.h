#pragma once
#include <windows.h>
#include <gdiplus.h>


inline void DrawMainCircle(Gdiplus::Graphics &g, const Gdiplus::Rect &circleRect) {
    //������Բ�Ķѵ���Ӱ
    const int shadowSteps = 12;
    for (int i = shadowSteps; i >= 1; --i) {
        int alpha = (int)(140.0f * (float)i / (float)shadowSteps);
        if (alpha > 255) alpha = 255;
        Gdiplus::Color shadowColor((BYTE)alpha, 200, 200, 200);
        Gdiplus::SolidBrush shadowBrush(shadowColor);

        int inflate = (shadowSteps - i) * 3;
        Gdiplus::Rect r(circleRect);
        r.X -= inflate/2;
        r.Y -= inflate/2;
        r.Width += inflate;
        r.Height += inflate;
        g.FillEllipse(&shadowBrush, r);
    }

    //Բ���������
    Gdiplus::SolidBrush creamBrush(Gdiplus::Color(255, 250, 240));
    g.FillEllipse(&creamBrush, circleRect);

    //��Բ�ϻ���һ����͵ĸ߹�
    int hW = circleRect.Width / 4;
    int hH = circleRect.Height / 4;
    Gdiplus::Rect highlightRect(circleRect.X + circleRect.Width / 12, circleRect.Y + circleRect.Height / 12, hW, hH);
    {
        Gdiplus::GraphicsPath path;
        path.AddEllipse(highlightRect);
        Gdiplus::PathGradientBrush pgb(&path);
        Gdiplus::Color centerColor(200, 255, 255, 255);
        pgb.SetCenterColor(centerColor);
        Gdiplus::Color surroundColors[1] = { Gdiplus::Color(0, 255, 255, 255) };
        INT surroundCount = 1;
        pgb.SetSurroundColors(surroundColors, &surroundCount);
        pgb.SetFocusScales(0.5f, 0.5f);
        g.FillPath(&pgb, &path);
    }

    //���Ʊ�Ե��
    Gdiplus::Pen rimPen(Gdiplus::Color(64, 220, 220, 220), 2.0f);
    g.DrawEllipse(&rimPen, circleRect);
}
