#include "Fuck8AM.h"

int main() {
    return RunFuck8AM();
}
