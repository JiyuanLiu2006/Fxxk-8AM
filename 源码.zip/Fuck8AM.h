#pragma once
#include <windows.h>
#include <gdiplus.h>
#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include "Circle.h"
#include "Wheel.h"
#include "Button.h"
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdiplus.lib")
int RunFuck8AM();


//ȫ�ֱ���
static HWND g_hWnd = nullptr;
static ULONG_PTR g_gdiplusToken = 0;
static bool g_wheelInitialized = false;
static Gdiplus::Color g_wheelColors[3];
static Gdiplus::Rect g_wheelRect;
static float g_wheelAngle = 0.0f; 
static bool g_animating = false;
static float g_animStartAngle = 0.0f;
static float g_animTargetAngle = 0.0f;
static unsigned long long g_animStartTime = 0;
static unsigned long long g_animDuration = 0;
static Gdiplus::Rect g_btnRect;
static bool g_btnPressed = false;
static bool g_btnHover = false;
static const UINT_PTR TIMER_ID = 1;
static Gdiplus::Bitmap *g_cachedBackground = nullptr;
static Gdiplus::Bitmap *g_cachedWheel = nullptr;
static MMRESULT g_mmTimerId = 0;
static const UINT WM_HIGHRES_TIMER = WM_APP + 1;
static float g_displayAngle = 0.0f;
static unsigned long long g_lastPaintTime = 0;

static void CALLBACK HighResTimerProc(UINT uTimerID, UINT uMsg, DWORD_PTR dwUser, DWORD_PTR dw1, DWORD_PTR dw2) {
    HWND h = (HWND)dwUser;
    if (h) PostMessageW(h, WM_HIGHRES_TIMER, 0, 0);
}
static inline float easeInOutCubic(float t) {
    if (t < 0.5f) return 4.0f * t * t * t;
    float f = (2.0f * t) - 2.0f;
    return 0.5f * f * f * f + 1.0f;
}

static void InitWheelColorsOnce() {
    if (g_wheelInitialized) return;
    g_wheelInitialized = true;
    //Ī����ɫϵԤ��
    static const Gdiplus::Color palettes[][3] = {
        { Gdiplus::Color(255, 176, 167, 156), Gdiplus::Color(255, 168, 180, 166), Gdiplus::Color(255, 200, 198, 186) },
        { Gdiplus::Color(255, 152, 160, 153), Gdiplus::Color(255, 180, 168, 168), Gdiplus::Color(255, 200, 190, 185) },
        { Gdiplus::Color(255, 162, 151, 155), Gdiplus::Color(255, 153, 161, 169), Gdiplus::Color(255, 183, 178, 170) },
        { Gdiplus::Color(255, 145, 152, 150), Gdiplus::Color(255, 170, 166, 160), Gdiplus::Color(255, 195, 190, 185) }
    };
    const int paletteCount = sizeof(palettes) / sizeof(palettes[0]);
    std::srand((unsigned)std::time(nullptr));
    int idx = std::rand() % paletteCount;
   
    for (int i = 0; i < 3; ++i) {
        Gdiplus::Color c = palettes[idx][i];
        int r = c.GetR();
        int g = c.GetG();
        int b = c.GetB();
        r = r + (int)((255 - r) * 0.40f);
        g = g + (int)((255 - g) * 0.40f);
        b = b + (int)((255 - b) * 0.40f);
        if (r > 255) r = 255;
        if (g > 255) g = 255;
        if (b > 255) b = 255;
        float lum = 0.299f * r + 0.587f * g + 0.114f * b;
        const float satBoost = 1.0f; 
        int rr = (int)(lum + (r - lum) * (1.0f + satBoost));
        int gg = (int)(lum + (g - lum) * (1.0f + satBoost));
        int bb = (int)(lum + (b - lum) * (1.0f + satBoost));
        const float contrastBoost = 0.35f; 
        rr = (int)((rr - 128) * (1.0f + contrastBoost) + 128);
        gg = (int)((gg - 128) * (1.0f + contrastBoost) + 128);
        bb = (int)((bb - 128) * (1.0f + contrastBoost) + 128);
        if (rr < 0) rr = 0; if (rr > 255) rr = 255;
        if (gg < 0) gg = 0; if (gg > 255) gg = 255;
        if (bb < 0) bb = 0; if (bb > 255) bb = 255;
        g_wheelColors[i] = Gdiplus::Color(255, rr, gg, bb);
    }
}

static LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_LBUTTONDOWN: {
        int mx = (int)(short)LOWORD(lParam);
        int my = (int)(short)HIWORD(lParam);
        if (g_btnRect.Contains(mx, my)) {
            g_btnPressed = true;
            SetCapture(hWnd);
            InvalidateRect(hWnd, NULL, FALSE);
        }
        return 0;
    }
    case WM_LBUTTONUP: {
        int mx = (int)(short)LOWORD(lParam);
        int my = (int)(short)HIWORD(lParam);
        if (g_btnPressed) {
            g_btnPressed = false;
            ReleaseCapture();
            InvalidateRect(hWnd, NULL, FALSE);
            if (!g_animating && g_btnRect.Contains(mx, my)) {
                std::srand((unsigned)std::time(nullptr));
                g_animating = true;
                g_animStartAngle = g_wheelAngle;
                //�����תһ������Ƕȣ�����һȦ�����ʮȦ
                float randomDeg = 360.0f + static_cast<float>(std::rand() % (360 * 9));
                g_animTargetAngle = g_animStartAngle + randomDeg;
                g_animStartTime = timeGetTime();
                g_animDuration = 3000 + (std::rand() % 2000); 
                if (g_mmTimerId) timeKillEvent(g_mmTimerId);
                g_mmTimerId = timeSetEvent(16, 1, HighResTimerProc, (DWORD_PTR)hWnd, TIME_PERIODIC | TIME_CALLBACK_FUNCTION);
            }
        }
        return 0;
    }
    case WM_MOUSEMOVE: {
        int mx = (int)(short)LOWORD(lParam);
        int my = (int)(short)HIWORD(lParam);
        bool inside = g_btnRect.Contains(mx, my);
        if (inside != g_btnHover) {
            g_btnHover = inside;
            InvalidateRect(hWnd, NULL, FALSE);
        }
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps); {
            Gdiplus::Graphics g(hdc);
            g.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
            //����ʱ�����²�ֵ��ʾ�Ƕ�
            unsigned long long nowPaint = GetTickCount64();
            if (g_lastPaintTime == 0) g_lastPaintTime = nowPaint;
            float dt = (nowPaint > g_lastPaintTime) ? (float)(nowPaint - g_lastPaintTime) / 1000.0f : 0.016f;
            g_lastPaintTime = nowPaint;
            //����ʾ�ǶȲ�ֵ����ʵ���̽Ƕ�
            const float interpSpeed = 12.0f; 
            float diff = g_wheelAngle - g_displayAngle;
            while (diff > 180.0f) diff -= 360.0f;
            while (diff < -180.0f) diff += 360.0f;
            g_displayAngle += diff * fminf(1.0f, interpSpeed * dt);

            //�ͻ����뻺�汳��
            RECT client;
            GetClientRect(hWnd, &client);
            int clientWpx = client.right - client.left;
            int clientHpx = client.bottom - client.top;

            InitWheelColorsOnce();

            //���δ���汳�����򴴽������Ʊ�������Բ��λͼ����ͬʱ׼������λͼ�뾲̬�߹�
            if (!g_cachedBackground) {
                //׼�����汳��
                g_cachedBackground = new Gdiplus::Bitmap(clientWpx, clientHpx, PixelFormat32bppPARGB);
                Gdiplus::Graphics bgG(g_cachedBackground);
                bgG.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
                Gdiplus::SolidBrush bgBrush(Gdiplus::Color(240, 240, 240));
                bgG.FillRectangle(&bgBrush, 0, 0, clientWpx, clientHpx);
                //������Բ�����Ƶ�������
                int diameter = static_cast<int>(clientWpx * 0.85f);
                if (diameter > clientHpx) diameter = clientHpx;
                int radius = diameter / 2;
                int cx = clientWpx / 2;
                int cy = clientHpx / 2;
                Gdiplus::Rect circleRect(cx - radius, cy - radius, diameter, diameter);
                DrawMainCircle(bgG, circleRect);

                //��������Ƶ������Ա�����˸
                int gapTop = circleRect.Y;
                if (gapTop > 10) {
                    Gdiplus::RectF layoutRect(0.0f, 0.0f, static_cast<Gdiplus::REAL>(clientWpx), static_cast<Gdiplus::REAL>(gapTop));
                    float fontPixelSize = gapTop * 0.35f;
                    if (fontPixelSize < 10.0f) fontPixelSize = 5.0f;
                    Gdiplus::Font font(L"Microsoft YaHei", fontPixelSize, Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
                    bgG.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAliasGridFit);
                    Gdiplus::SolidBrush textBrush(Gdiplus::Color(255, 64, 64, 64));
                    Gdiplus::StringFormat fmt;
                    fmt.SetAlignment(Gdiplus::StringAlignmentCenter);
                    fmt.SetLineAlignment(Gdiplus::StringAlignmentCenter);
                    const WCHAR title[] = L"����ȥ�����";
                    bgG.DrawString(title, -1, &font, layoutRect, &fmt, &textBrush);
                }

                int wheelDiameter = static_cast<int>(diameter * 0.92f);
                if (wheelDiameter < 4) wheelDiameter = 4;
                g_cachedWheel = new Gdiplus::Bitmap(wheelDiameter, wheelDiameter, PixelFormat32bppPARGB);
                Gdiplus::Graphics wg(g_cachedWheel);
                wg.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
                wg.Clear(Gdiplus::Color(0,0,0,0));
                int wr = wheelDiameter / 2;
                const int bisectorAngles[3] = { -90, 30, 150 };
                for (int i = 0; i < 3; ++i) {
                    int startAngle = bisectorAngles[i] - 60; //ɨ��120�ȣ���ʼ��Ϊ���߼����
                    Gdiplus::SolidBrush b(g_wheelColors[i]);
                    wg.FillPie(&b, 0, 0, wheelDiameter, wheelDiameter, startAngle, 120);
                }


                int wheelCx = cx;
                int wheelCy = cy;
                int wheelRadius = wheelDiameter / 2;
                Gdiplus::Rect hlRect(wheelCx - wheelRadius + wheelDiameter/12, wheelCy - wheelRadius + wheelDiameter/12, wheelDiameter/4, wheelDiameter/4);
                Gdiplus::GraphicsPath path;
                path.AddEllipse(hlRect);
                Gdiplus::PathGradientBrush pgb(&path);
                Gdiplus::Color centerColor(200, 255, 255, 255);
                pgb.SetCenterColor(centerColor);
                Gdiplus::Color surround[1] = { Gdiplus::Color(0,255,255,255) };
                INT sc = 1;
                pgb.SetSurroundColors(surround, &sc);
                pgb.SetFocusScales(0.6f, 0.6f);
                bgG.FillPath(&pgb, &path);
            }

            Gdiplus::Bitmap backbuf(clientWpx, clientHpx, PixelFormat32bppPARGB);
            Gdiplus::Graphics bufG(&backbuf);
            bufG.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
            bufG.DrawImage(g_cachedBackground, 0, 0);

            int diameter = static_cast<int>(clientWpx * 0.85f);
            if (diameter > clientHpx) 
                diameter = clientHpx;
            int radius = diameter / 2;
            int cx = clientWpx / 2;
            int cy = clientHpx / 2;
            Gdiplus::Rect circleRect(cx - radius, cy - radius, diameter, diameter);


            int gapTop = circleRect.Y;

            InitWheelColorsOnce();
            if (g_cachedWheel) {
                int wheelDiameter = g_cachedWheel->GetWidth();
                int wheelRadius = wheelDiameter / 2;
                int wheelCx = cx;
                int wheelCy = cy;
                g_wheelRect = Gdiplus::Rect(wheelCx - wheelRadius, wheelCy - wheelRadius, wheelDiameter, wheelDiameter);
                Gdiplus::Matrix old;
                bufG.GetTransform(&old);
                bufG.TranslateTransform((Gdiplus::REAL)wheelCx, (Gdiplus::REAL)wheelCy);
                bufG.RotateTransform(g_displayAngle);
                bufG.TranslateTransform((Gdiplus::REAL)-wheelRadius, (Gdiplus::REAL)-wheelRadius);
                bufG.DrawImage(g_cachedWheel, 0, 0);
                bufG.SetTransform(&old);
            } else {
                int wheelDiameter = static_cast<int>(diameter * 0.92f);
                int wheelRadius = static_cast<int>(wheelDiameter * 0.5f);
                int wheelCx = cx;
                int wheelCy = cy; 
                g_wheelRect = Gdiplus::Rect(wheelCx - wheelRadius, wheelCy - wheelRadius, wheelDiameter, wheelDiameter);
                DrawWheel(bufG, g_wheelRect, g_wheelAngle, g_wheelColors);
            }

            //���ƹ̶�����ı�ǩ
            //�����ǩ����
            float titleFontPixel = gapTop * 0.35f;
            float labelFontSize = (titleFontPixel - 2.0f) * 0.5f; 
            if (labelFontSize < 6.0f) labelFontSize = 6.0f;
            Gdiplus::Font labelFont(L"Microsoft YaHei", labelFontSize, Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
            Gdiplus::SolidBrush labelBrush(Gdiplus::Color(255, 64, 64, 64));
            Gdiplus::StringFormat labelFmt;
            labelFmt.SetAlignment(Gdiplus::StringAlignmentCenter);
            labelFmt.SetLineAlignment(Gdiplus::StringAlignmentCenter);
            labelFmt.SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap);
            labelFmt.SetTrimming(Gdiplus::StringTrimmingEllipsisCharacter);
            bufG.SetTextRenderingHint(Gdiplus::TextRenderingHintClearTypeGridFit);

            const float PI_f = 3.14159265f;
            float wheelR = (float)(g_wheelRect.Width) / 2.0f;
            float labelRadius = wheelR * 0.75f;
            float pad = labelFontSize * 0.6f;
            if (labelRadius > wheelR - pad) labelRadius = wheelR - pad;
            if (labelRadius < wheelR * 0.55f) labelRadius = wheelR * 0.55f;

            auto drawLabelAtHour = [&](const WCHAR *text, int hour) {
                float angleDeg = hour * 30.0f - 90.0f; 
                float rad = angleDeg * PI_f / 180.0f;
                float px = (float)cx + cosf(rad) * labelRadius;
                float py = (float)cy + sinf(rad) * labelRadius;
                Gdiplus::RectF tf(px - 80.0f, py - labelFontSize, 160.0f, labelFontSize * 2.0f);
                Gdiplus::GraphicsPath textPath;
                Gdiplus::FontFamily ff(L"Microsoft YaHei");
                textPath.AddString(text, -1, &ff, Gdiplus::FontStyleRegular, labelFontSize, tf, &labelFmt);
                float penWidth = max(1.0f, labelFontSize * 0.18f);
                Gdiplus::Pen outlinePen(Gdiplus::Color(160, 255, 255, 255), penWidth);
                outlinePen.SetLineJoin(Gdiplus::LineJoinRound);
                bufG.DrawPath(&outlinePen, &textPath);
                bufG.FillPath(&labelBrush, &textPath);
            };

            drawLabelAtHour(L"��ȥ", 12);
            drawLabelAtHour(L"ȥ", 4);
            drawLabelAtHour(L"˯��ȥ", 8);

            //�������ϼ�ͷ
            {
                float wheelRadiusF = (float)g_wheelRect.Width / 2.0f;
                float arrowLen = wheelRadiusF * 0.60f;
                const int shadowSteps = 12;
                float headLen = arrowLen * 0.20f; 
                float hw = arrowLen * 0.08f; 
                float sw = max(1.0f, arrowLen * 0.025f); 
                float circleCx = (float)cx;
                float circleCy = (float)cy;
                float circleRadius = hw;
                float tailY = circleCy - circleRadius;
                float headBaseY = (float)(cy - arrowLen + headLen);
                Gdiplus::PointF pts[7];
                pts[0] = Gdiplus::PointF((Gdiplus::REAL)cx, (Gdiplus::REAL)(cy - arrowLen)); // tip
                pts[1] = Gdiplus::PointF((Gdiplus::REAL)(cx + hw*0.5f), headBaseY);
                pts[2] = Gdiplus::PointF((Gdiplus::REAL)(cx + sw*0.5f), headBaseY);
                pts[3] = Gdiplus::PointF((Gdiplus::REAL)(cx + sw*0.5f), tailY);
                pts[4] = Gdiplus::PointF((Gdiplus::REAL)(cx - sw*0.5f), tailY);
                pts[5] = Gdiplus::PointF((Gdiplus::REAL)(cx - sw*0.5f), headBaseY);
                pts[6] = Gdiplus::PointF((Gdiplus::REAL)(cx - hw*0.5f), headBaseY);

                float circleRadiusLocal = hw; 
                float circleCxLocal = (float)cx;
                float circleCyLocal = (float)cy;
                Gdiplus::GraphicsPath combinedPath;
                combinedPath.AddPolygon(pts, 7);
                combinedPath.AddEllipse(circleCxLocal - circleRadiusLocal, circleCyLocal - circleRadiusLocal, circleRadiusLocal * 2.0f, circleRadiusLocal * 2.0f);

                for (int i = shadowSteps; i >= 1; --i) {
                    int alpha = (int)(140.0f * (float)i / (float)shadowSteps);
                    if (alpha > 255) alpha = 255;
                    Gdiplus::Color shadowColor((BYTE)alpha, 200, 200, 200);
                    Gdiplus::SolidBrush shadowBrush(shadowColor);
                    Gdiplus::GraphicsPath *p = combinedPath.Clone();
                    Gdiplus::Matrix m;
                    m.Translate(0.0f, (Gdiplus::REAL)((shadowSteps - i) * 1.0f), Gdiplus::MatrixOrderAppend);
                    p->Transform(&m);
                    bufG.FillPath(&shadowBrush, p);
                    delete p;
                }

                Gdiplus::SolidBrush arrowBrush(Gdiplus::Color(255, 160, 32, 32));
                bufG.FillPath(&arrowBrush, &combinedPath);
            }

            //��ťλ��
            int btnW = (int)(clientWpx / 4 * 1.2f); 
            int btnH = (int)(((24 > (diameter / 12)) ? 24 : (diameter / 12)) * 1.2f);
            int btnCx = cx;
            int circleBottom = circleRect.Y + circleRect.Height;
            int btnCy = (circleBottom + clientHpx) / 2; 
            g_btnRect = Gdiplus::Rect(btnCx - btnW/2, btnCy - btnH/2, btnW, btnH);
            titleFontPixel = gapTop * 0.35f;
            float btnFontSize = titleFontPixel * 0.55f;
            if (btnFontSize < 6.0f) btnFontSize = 6.0f;
            DrawButton(bufG, g_btnRect, L"��ʼ����", btnFontSize, Gdiplus::Color(255,64,64,64), Gdiplus::Color(255,250,240,240), g_btnHover, g_btnPressed);

            g.DrawImage(&backbuf, 0, 0);
        }
        EndPaint(hWnd, &ps);
        return 0;
    }
    case WM_TIMER: {
        if (wParam == TIMER_ID && g_animating) {
            unsigned long long now = GetTickCount64();
            unsigned long long elapsed = now - g_animStartTime;
            if (elapsed >= g_animDuration) {
                g_wheelAngle = g_animTargetAngle;
                g_animating = false;
                if (g_mmTimerId) {
                    timeKillEvent(g_mmTimerId);
                    g_mmTimerId = 0;
                }
                
                MessageBoxW(g_hWnd, L"������������\n������Υ����һ�ж�����õİ��ţ�", L"������", MB_OK | MB_ICONINFORMATION);
            } else {
                float t = (float)elapsed / (float)g_animDuration;
                float eased = easeInOutCubic(t);
                g_wheelAngle = g_animStartAngle + (g_animTargetAngle - g_animStartAngle) * eased;
            }
            InvalidateRect(hWnd, NULL, FALSE);
        }
        return 0;
    }
    case WM_HIGHRES_TIMER: {
        if (g_animating) {
            unsigned long long now = timeGetTime();
            unsigned long long elapsed = now - g_animStartTime;
            if (elapsed >= g_animDuration) {
                g_wheelAngle = g_animTargetAngle;
                g_animating = false;
                if (g_mmTimerId) { timeKillEvent(g_mmTimerId); g_mmTimerId = 0; }
                MessageBoxW(g_hWnd, L"������������\n������Υ����һ�ж�����õİ��ţ�", L"������", MB_OK | MB_ICONINFORMATION);
            } else {
                float t = (float)elapsed / (float)g_animDuration;
                float eased = easeInOutCubic(t);
                g_wheelAngle = g_animStartAngle + (g_animTargetAngle - g_animStartAngle) * eased;
            }
            InvalidateRect(hWnd, NULL, FALSE);
        }
        return 0;
    }
    case WM_DESTROY:
        if (g_cachedBackground) {
            delete g_cachedBackground;
            g_cachedBackground = nullptr;
        }
        if (g_cachedWheel) {
            delete g_cachedWheel;
            g_cachedWheel = nullptr;
        }
        if (g_mmTimerId) {
            timeKillEvent(g_mmTimerId);
            g_mmTimerId = 0;
        }
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }
}

int RunFuck8AM() {
    //DPI��֪
    typedef BOOL(WINAPI *SetProcessDpiAwarenessContext_t)(HANDLE);
    typedef HRESULT(WINAPI *SetProcessDpiAwareness_t)(int);
    typedef BOOL(WINAPI *SetProcessDPIAware_t)();

    
    HMODULE hUser32 = GetModuleHandleW(L"user32.dll");
    SetProcessDpiAwarenessContext_t pSetDpiCtx = nullptr;
    if (hUser32)
        pSetDpiCtx = (SetProcessDpiAwarenessContext_t)GetProcAddress(hUser32, "SetProcessDpiAwarenessContext");
    if (pSetDpiCtx) {
        pSetDpiCtx((HANDLE)-4);
    } else {
        HMODULE hShcore = GetModuleHandleW(L"shcore.dll");
        if (hShcore) {
            SetProcessDpiAwareness_t pSetProcDpi = (SetProcessDpiAwareness_t)GetProcAddress(hShcore, "SetProcessDpiAwareness");
            if (pSetProcDpi) {
                pSetProcDpi(2);
            }
        } else {
            SetProcessDPIAware_t pSetDPIAware = nullptr;
            if (hUser32)
                pSetDPIAware = (SetProcessDPIAware_t)GetProcAddress(hUser32, "SetProcessDPIAware");
            if (pSetDPIAware)
                pSetDPIAware();
        }
    }

    //���ؿ���̨����
    HWND hConsole = GetConsoleWindow();
    if (hConsole)
        ShowWindow(hConsole, SW_HIDE);

    //����DPI����
    int screenDPI = 96;
    HDC hScreenDC = GetDC(nullptr);
    if (hScreenDC) {
        screenDPI = GetDeviceCaps(hScreenDC, LOGPIXELSX);
        ReleaseDC(nullptr, hScreenDC);
    }
    float initialScale = (float)screenDPI / 96.0f;

    //��ʼ��GDI+
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    if (Gdiplus::GdiplusStartup(&g_gdiplusToken, &gdiplusStartupInput, nullptr) != Gdiplus::Ok)
        return -1;

    HINSTANCE hInstance = GetModuleHandle(nullptr);

    const wchar_t CLASS_NAME[] = L"No8AMWindowClass";

    WNDCLASS wc = {};
    wc.style = CS_HREDRAW | CS_VREDRAW; 
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);

    RegisterClass(&wc);

    //�߶�Ϊ��������������������*85%�����ȸ��� 3:4 ���߱ȴӸ߶ȼ���
    RECT workArea = {};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &workArea, 0);
    int usableW = workArea.right - workArea.left;
    int usableH = workArea.bottom - workArea.top;
    int desiredClientHpx = static_cast<int>(usableH * 0.85f);
    int desiredClientWpx = static_cast<int>(desiredClientHpx * 3.0f / 4.0f);
    if (desiredClientWpx > usableW) {
        desiredClientWpx = usableW;
        desiredClientHpx = static_cast<int>(desiredClientWpx * 4.0f / 3.0f);
        if (desiredClientHpx > usableH)
            desiredClientHpx = usableH;
    }
    RECT rect = { 0, 0, desiredClientWpx, desiredClientHpx };
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX; 
    AdjustWindowRect(&rect, style, FALSE);
    int winW = rect.right - rect.left;
    int winH = rect.bottom - rect.top;

    int screenW = GetSystemMetrics(SM_CXSCREEN);
    //�����ڴ�ֱ�����ڹ�����
    int x = (screenW - winW) / 2;
    int y = workArea.top + (usableH - (rect.bottom - rect.top)) / 2;

    g_hWnd = CreateWindowEx(0, CLASS_NAME, L"�������", style, x, y, winW, winH, nullptr, nullptr, hInstance, nullptr);
    if (!g_hWnd) {
        Gdiplus::GdiplusShutdown(g_gdiplusToken);
        return -1;
    }

    ShowWindow(g_hWnd, SW_SHOWDEFAULT);
    UpdateWindow(g_hWnd);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    Gdiplus::GdiplusShutdown(g_gdiplusToken);
    return static_cast<int>(msg.wParam);
}

