#pragma once
#include <windows.h>
#include <gdiplus.h>


inline void DrawWheel(Gdiplus::Graphics &g, const Gdiplus::Rect &wheelRect, float angleDegrees, const Gdiplus::Color colors[3]) {
    //��Ӱ
    const int wheelShadowSteps = 6;
    for (int i = wheelShadowSteps; i >= 1; --i) {
        int alpha = (int)(120.0f * (float)i / (float)wheelShadowSteps);
        if (alpha > 255) alpha = 255;
        Gdiplus::Color shadowColor((BYTE)alpha, 200, 200, 200);
        Gdiplus::SolidBrush shadowBrush(shadowColor);
        int inflate = (wheelShadowSteps - i) * 2;
        Gdiplus::Rect r2(wheelRect);
        r2.X -= inflate/2;
        r2.Y -= inflate/2;
        r2.Width += inflate;
        r2.Height += inflate;
        g.FillEllipse(&shadowBrush, r2);
    }

    //��������
    int wheelDiameter = wheelRect.Width;
    int wheelRadius = wheelDiameter / 2;

    Gdiplus::Matrix oldTransform;
    g.GetTransform(&oldTransform);
    g.TranslateTransform(static_cast<Gdiplus::REAL>(wheelRect.GetLeft() + wheelRect.Width/2), static_cast<Gdiplus::REAL>(wheelRect.GetTop() + wheelRect.Height/2));
    g.RotateTransform(angleDegrees);
    int startAngle = 0;
    for (int i = 0; i < 3; ++i) {
        Gdiplus::SolidBrush b(colors[i]);
        g.FillPie(&b, -wheelRadius, -wheelRadius, wheelDiameter, wheelDiameter, startAngle, 120);
        startAngle += 120;
    }

    //��͸���߹�
    Gdiplus::SolidBrush highlightBrush(Gdiplus::Color(120, 255, 255, 255));
    Gdiplus::RectF hlRectF(static_cast<Gdiplus::REAL>(-wheelRadius + wheelDiameter/12), static_cast<Gdiplus::REAL>(-wheelRadius + wheelDiameter/12), static_cast<Gdiplus::REAL>(wheelDiameter/4), static_cast<Gdiplus::REAL>(wheelDiameter/4));
    g.FillEllipse(&highlightBrush, hlRectF);

    g.SetTransform(&oldTransform);
}
